<!DOCTYPE html>
<html>

	<head>
	
		<meta charset='utf-8'>
		<link href="style.css" type="text/css" rel="stylesheet" />
    
	</head>
	
	<body>
		<?php include('front.php'); ?>
		
		<h2> Acceuil </h2>
		
		<h3> Task done </h3>
		
			<table>
				<thead>
					<tr>
						<th>Tasks</th>
						<th>Undone</th>
						<th>Delete</th>
					</tr>
				</thead>

				<tbody>
					<?php 
					
					 // initialize errors variable
					$errors = "";

					// connect to database
					$database = mysqli_connect("localhost", "root", "", "DataBaseTask");

					// select all tasks if page is visited or refreshed
					$tasks = mysqli_query($database, "SELECT * FROM task WHERE state = 1");

					$i = 1; while ($row = mysqli_fetch_array($tasks)) {
						$var = $row['id']; 
					?>
						<tr>
							<td class="task"> <?php echo $row['name']; ?> </td>
							<td class="checkCase"> 
								<?php echo " <a href='http://localhost/ToDoList/ChangeStatus.php?etat=0&ident=".$row['id']."'> " ."x". "</a>"; ?>
								
							</td>
							<td class="checkCase"> 
								<?php echo " <a href='http://localhost/ToDoList/DeleteTask.php?etat=0&ident=".$row['id']."'> " ."supprimer". "</a>"; ?>
								
							</td>
						</tr>
					<?php $i++; } ?>	
				</tbody>
			</table>
			
			
		<?php

			$database = null; 
			$tasks = null;
		
		?>
		
		<?php include('footer.php'); ?>
	</body>
	
</html>