<?php 
    // initialize errors variable
	$errors = "";

	// connect to database
	$db = mysqli_connect("localhost", "root", "", "DataBaseTask");

	// insert a quote if submit button is clicked		
	$etat = $_GET['etat'];
	$identifiant = $_GET['ident'];
	
	$sql = "DELETE From task WHERE id='$identifiant'";
	mysqli_query($db, $sql);
	
	if ($etat == 1)
	{
		header('location: TaskToDo.php');
	}
	else
	{
		header('location: TaskDone.php');
			
	}
	
	$db = null;
	$sql = null;
?>