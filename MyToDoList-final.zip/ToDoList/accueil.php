<!DOCTYPE html>
<html>

	<head>
	
		<meta charset='utf-8'>
		<link href="style.css" type="text/css" rel="stylesheet" />
    
	</head>
	
	<body>
		<?php include('front.php'); ?>
		
		<h2> Acceuil </h2>
		
		<h3> To do list </h3>
		
		<form method="post" action="ActionAddTask.php" class="input_form">
			<input type="text" name="task" class="task_input">
			<button type="submit" name="submit" id="add_btn" class="add_btn">Add Task</button>
		</form>
		
		
		<?php
		
			try
			{
				$database = new PDO('mysql:host=localhost;dbname=databasetask', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
			}
			catch (PDOException $e)
			{
				echo 'Echec de la connexion : ' . $e->getMessage();
				exit;
			}
			
			
			$requete = $database->query('SELECT * FROM task WHERE state = 0');
			
			echo '<h5> Tâches à faire </h5>';
			
			while ($donnees = $requete->fetch())
			{
				echo '<li>' . $donnees['name'] . '</li>';
			}  
			
			$requete = $database->query('SELECT * FROM task WHERE state = 1');
			
			echo '<h5> Tâches finit</h5>';
			
			while ($donnees = $requete->fetch())
			{
				echo '<li>' . $donnees['name'] . '</li>';
			}  
			
			$requete = null;
			$database = null; 
		
		?>
		
		
		<?php include('footer.php'); ?>
	</body>
	
</html>