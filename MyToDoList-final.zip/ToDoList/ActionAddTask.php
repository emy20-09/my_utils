<?php 
    // initialize errors variable
	$errors = "";

	// connect to database
	$db = mysqli_connect("localhost", "root", "", "DataBaseTask");

	// insert a quote if submit button is clicked
	if (isset($_POST['submit'])) {
		if (empty($_POST['task'])) {
			$errors = "You must fill in the task";
		}else{
			
			$etat = 0;
			$tache = $_POST['task'];
	
			$sql = "INSERT INTO task ( name, state) VALUES ('$tache','$etat')";
			mysqli_query($db, $sql);
			
			$sql = null;
		}
	}	
	
	header('Location: accueil.php');
	
	$db = null;
?>