<!DOCTYPE html>
<html>

	<head>
	
		<meta charset='utf-8'>
		<link href="style.css" type="text/css" rel="stylesheet" />
    
	</head>
	
	<body>
		<footer>
			<?php 

				echo "<p> My Utils - To Do List - Emy Rivaud  </p>";
			
			?>
		</footer>
	</body>
</html>