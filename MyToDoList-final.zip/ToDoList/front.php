<!DOCTYPE html>
<html>

	<head>
	
		<title> Mon DevBlog </title>
		<meta charset='utf-8'>
		<link href="style.css" type="text/css" rel="stylesheet" />
    
	</head>
	
	<body>
		<div class="container">
		
			<h1> Mon DevBlog </h1>

			<nav>
				<a href="http://localhost/ToDoList/front.php?page=1\">Page d'accueil </a> 
				<a href="http://localhost/ToDoList/front.php?page=2\">Liste des tâches à faire </a> 
				<a href="http://localhost/ToDoList/front.php?page=3\">Liste des tâches finit </a> 
			</nav>
			
			
			<?php
			
			if (isset($_GET['page'])) {
				if ($_GET['page'] == 1)
				{
					header('Location: accueil.php');
				}		
				elseif ($_GET['page'] == 2)
				{
					header('Location: TaskToDo.php');
					
				}
				elseif ($_GET['page'] == 3)
				{
					header('Location: TaskDone.php');
				}
			}

			
            ?>
			
		</div>
		
	</body>
	
</html>